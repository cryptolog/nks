Before the run a file, PLS TURN OFF YOUR ANTIVIRUS!
Because file unoffical and will be detected how malware.